from pathlib import Path
import json,hashlib,sys,platform,importlib.metadata,zipfile
import h5py,numpy as np,pandas as pd
from anndata.io import read_elem
R=Path(__file__).resolve().parents[1]
INPUT=Path('/data/scAtlas/AML_scAtlas_CELLxGENE.h5ad')
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(16*1024**2),b''): h.update(b)
 return h.hexdigest()
model={'genes':['ACADSB','ACAT2','ALDH2','BCAT1','OXCT1'],'coefficients':{'ACADSB':-0.178767,'ACAT2':0.209873,'ALDH2':0.249398,'BCAT1':0.124791,'OXCT1':0.168692},'source':'User-supplied original v28 coefficients; user explicitly waived original final_model.json on 2026-11-11. Six decimal precision as supplied. No refitting.','score_definition':'Transferred expression descriptor: sum of coefficients times AML-donor-cohort z scores (ddof=0) of log2(1+CPM); not calibrated survival risk.'}
mp=R/'inputs'/'model_user_specification.json';mp.write_text(json.dumps(model,indent=2))
with h5py.File(INPUT,'r') as f:
 o=read_elem(f['obs']);v=read_elem(f['var']);rv=read_elem(f['raw/var']);u=read_elem(f['uns'])
 assert o.index.is_unique and v.index.is_unique
 assert list(v.index)==list(rv.index)
 o.index.name='cell_id';o.to_csv(R/'intermediate'/'cell_metadata.csv.gz')
 v.to_csv(R/'intermediate'/'gene_metadata.csv.gz')
 np.save(R/'intermediate'/'atlas_umap.npy',f['obsm/X_scVI_umap'][:])
 counts=o.groupby(['donor_id','Sample','Study','disease','Author Cell Type'],observed=True).size().rename('n_cells').reset_index()
 counts.to_csv(R/'tables'/'sample_celltype_coverage.csv',index=False)
 for cols,name in [(['donor_id','Study','disease','Author Cell Type'],'donor_celltype_coverage'),(['donor_id','Study','disease','HSPC Cell Type'],'donor_hspc_coverage')]:
  sub=o if 'HSPC Cell Type' not in cols else o[o['Author Cell Type']=='HSPC']
  sub.groupby(cols,observed=True).size().rename('n_cells').reset_index().to_csv(R/'tables'/f'{name}.csv',index=False)
 fields=['Study','disease','Main Age Group','Fine Age Group','age_floor','sex','ELN Classification','ELN Risk Group','Mutations','Cytogenetics','Translocations','assay','tissue']
 donor=o.groupby('donor_id',observed=True)[fields].first()
 donor['n_cells']=o.groupby('donor_id',observed=True).size()
 donor['n_samples']=o.groupby('donor_id',observed=True)['Sample'].nunique()
 donor['samples']=o.groupby('donor_id',observed=True)['Sample'].agg(lambda x:';'.join(sorted(set(x))))
 donor.to_csv(R/'tables'/'donor_inventory.csv')
 conflicts=o.groupby('donor_id',observed=True)[fields].nunique()
 conflicts.to_csv(R/'tables'/'donor_metadata_distinct_counts.csv')
 assert not (conflicts[['Study','disease','Main Age Group']]>1).any().any()
 sample=o.groupby('Sample',observed=True)[['donor_id']+fields].first();sample['n_cells']=o.groupby('Sample',observed=True).size();sample.to_csv(R/'tables'/'sample_inventory.csv')
 st=o.groupby(['Study','disease'],observed=True).agg(n_cells=('donor_id','size'),n_donors=('donor_id','nunique'),n_samples=('Sample','nunique'))
 st.to_csv(R/'tables'/'study_inventory.csv')
 print(st.to_string())
 stats={'n_cells':len(o),'n_genes':len(v),'n_donors':o.donor_id.nunique(),'n_samples':o.Sample.nunique(),'n_studies':o.Study.nunique(),'disease_donors':donor.disease.value_counts().to_dict(),'disease_cells':o.disease.value_counts().to_dict(),'hspc_missing_fine':int(((o['Author Cell Type']=='HSPC')&(o['HSPC Cell Type'].astype(str)=='NA')).sum()),'layers_keys':list(f['layers'].keys()),'X_shape':list(f['X'].attrs['shape']),'raw_shape':list(f['raw/X'].attrs['shape'])}
 print(json.dumps(stats,indent=2,default=int))
 idx=[np.flatnonzero(v.gene_symbol==g)[0] for g in model['genes']]
 pd.DataFrame({'gene':model['genes'],'ensembl':v.index[idx],'matrix_column':idx,'coefficient':[model['coefficients'][g] for g in model['genes']]}).to_csv(R/'tables'/'model_gene_mapping.csv',index=False)
 # Numerical scale check before full raw validation in step 02.
 scale=[]
 for name in ['X','raw/X']:
  d=f[name+'/data'];a=np.concatenate([d[i:min(i+10000,len(d))] for i in np.linspace(0,len(d)-10000,20,dtype=int)])
  scale.append(dict(matrix=name,n_checked=len(a),minimum=float(a.min()),maximum=float(a.max()),fraction_integer=float(np.mean(a==np.round(a))),negative=int((a<0).sum())))
 pd.DataFrame(scale).to_csv(R/'tables'/'matrix_scale_checks.csv',index=False)
 (R/'provenance'/'object_uns.json').write_text(json.dumps(u,default=lambda x:x.tolist() if hasattr(x,'tolist') else str(x),indent=2))
z=R/'inputs'/'automated_annotations.zip'
if z.exists():
 with zipfile.ZipFile(z) as f:
  name=next(n for n in f.namelist() if n.endswith('.csv') and not n.startswith('__MACOSX'))
  a=pd.read_csv(f.open(name),index_col=0)
 assert a.index.is_unique and set(a.index)==set(o.index)
 a=a.reindex(o.index)
 a.to_csv(R/'intermediate'/'automated_annotation_sidecar.csv.gz')
 pd.crosstab(o['Author Cell Type'],a['singler_cluster_label']).to_csv(R/'tables'/'annotation_crosscheck.csv')
 stats['downloaded_annotation_exact_id_match']=True
 stats['downloaded_annotation_columns']=a.columns.tolist()
(R/'provenance'/'inventory.json').write_text(json.dumps(stats,indent=2,default=int))
records={'input':str(INPUT),'input_sha256':sha(INPUT),'provided_sha256_file':INPUT.with_suffix(INPUT.suffix+'.sha256').read_text(),'model_specification_sha256':sha(mp),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'packages':{x:importlib.metadata.version(x) for x in ['scanpy','anndata','numpy','scipy','pandas','h5py','matplotlib','statsmodels','seaborn']}}
(R/'provenance'/'input_environment.json').write_text(json.dumps(records,indent=2))
print('Inventory and hashes complete',flush=True)
