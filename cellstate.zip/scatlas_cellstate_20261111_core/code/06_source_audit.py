from pathlib import Path
import json,pandas as pd
R=Path(__file__).resolve().parents[1]
study=pd.read_csv(R/'tables/study_inventory.csv');source=pd.read_excel(R/'inputs/study_sources.xlsx')
# Explicit mapping, no inference from donor identifiers or publication-year string equality.
mapping={'zheng_2017':0,'oetjen_2018':1,'van_galen_2019':2,'setty_2019':3,'petti_2019':4,'pei_2020':5,'caron_2020':6,'jiang_2020':7,'johnston_2020':8,'velten_2021':9,'stetson_2021':10,'zhai_2022':11,'human_cell_atlas':12,'lasry_2022':13,'li_2022':14,'naldini_2023':15,'beneyto-calabuig-2023':16,'zhang_2023':17,'mumme_2023':18,'fiskus_2023':19}
rows=[]
for st,i in mapping.items():
 s=source.iloc[i];q=study[study.Study==st]
 rows.append(dict(Study=st,source_table_study=s.Study,DOI=s.DOI,protocol=s.Protocol,source_table_samples=s['Samples Included'],public_data_source=s['Data Source'],actual_cells=int(q.n_cells.sum()),actual_donors=int(q.n_donors.sum()),actual_samples=int(q.n_samples.sum()),sampling_status='AML explicitly without enrichment; healthy BM5 enriched' if st=='van_galen_2019' else 'Per-sample enrichment unresolved; not approved for cross-study cell-composition inference',sampling_source='https://pmc.ncbi.nlm.nih.gov/articles/PMC6515904/' if st=='van_galen_2019' else 'Atlas methods notes CD34 enrichment in some studies, without sample-level mapping'))
pd.DataFrame(rows).to_csv(R/'tables/study_source_mapping.csv',index=False)
s=pd.read_csv(R/'tables/sample_inventory.csv',keep_default_na=False);s['timepoint_status']='Atlas selected diagnostic samples when treatment timepoints existed; no individual timepoint column';s['enrichment_status']='Unresolved per sample';s['enrichment_evidence']='Atlas article, author code and Source Data 1 lack a complete sample-to-sort mapping'
v=(s.Study=='van_galen_2019')&(s.disease!='normal');s.loc[v,'enrichment_status']='AML without enrichment, original study methods';s.loc[v,'enrichment_evidence']='https://pmc.ncbi.nlm.nih.gov/articles/PMC6515904/; retrieved BioC text'
v=(s.Study=='van_galen_2019')&(s.donor_id=='BM5');s.loc[v,'enrichment_status']='BM5 CD34 and CD34+CD38- fractions; exact fraction-to-Sample mapping unresolved';s.loc[v,'enrichment_evidence']='Original study Cell preparation section'
s.to_csv(R/'tables/sample_source_capabilities.csv',index=False)
# Export the capability table to a machine-readable file as well as the original design document.
lines=(R/'report/data_capability_and_design.md').read_text().splitlines();out=[]
for line in lines:
 if line.startswith('|') and not line.startswith('|---'):
  cols=line.strip('|').split('|')
  if len(cols)==3 and cols[0]!='项目':out.append(dict(field=cols[0],status=cols[1],evidence_and_limit=cols[2]))
out.extend([
 dict(field='本次最终主分析纳入',status='实际确定',evidence_and_limit='717809细胞、216样本、200供者（155 AML、45健康）、18研究；见analysis_donor_inclusion.csv。原对象库存及完整中间汇总仍保留全部207位供者。'),
 dict(field='Setty/Stetson原始计数尺度',status='尚不明确',evidence_and_limit='X反推值与整数raw存在取整差异；保留导出数据，未纳入主要计数尺度表达和评分。其余18研究X与raw的变换关系符合计数型输入。'),
 dict(field='固定模型文件来源',status='用户文本已确认',evidence_and_limit='用户明确无需原final_model.json；使用提供的五个六位小数系数，model_user_specification.json及哈希可复核。'),
 dict(field='两条Hallmark通路表达',status='已取得并完成探索',evidence_and_limit='MSigDB_Hallmark_2020公开快照已保存；剔除模型重叠基因后，胆固醇稳态68基因、mTORC1 185基因；研究/状态间关联异质，不称代谢通量。')
])
pd.DataFrame(out).to_csv(R/'tables/data_capability_table.csv',index=False)
print('Source mappings complete')
