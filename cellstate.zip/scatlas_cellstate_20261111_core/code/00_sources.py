"""Download public primary sources into this run only; retain hashes and URLs."""
from pathlib import Path
import urllib.request, json, hashlib, time
ROOT = Path(__file__).resolve().parents[1]
SOURCES = {
 'atlas_article.html': 'https://pmc.ncbi.nlm.nih.gov/articles/PMC12893711/',
 'study_sources.xlsx': 'https://cdn.elifesciences.org/articles/104978/elife-104978-data1-v1.xlsx',
 'automated_annotations.zip': 'https://cdn.elifesciences.org/articles/104978/elife-104978-fig1-data2-v1.zip',
 'author_annotations.py': 'https://raw.githubusercontent.com/jesswhitts/AML-scAtlas/revised/3_Analysis/4_Annotation/annotations.py',
 'author_hspc.py': 'https://raw.githubusercontent.com/jesswhitts/AML-scAtlas/revised/4_Extended_Analyses/1_HSPCs/HSPC_analysis.py',
 'github_tree.json': 'https://api.github.com/repos/jesswhitts/AML-scAtlas/git/trees/revised?recursive=1',
 'figshare_metadata.json': 'https://api.figshare.com/v2/articles/27269946',
 'author_combine.py':'https://raw.githubusercontent.com/jesswhitts/AML-scAtlas/revised/1_Initial_QC/3_IntegratedQC/combine_atlas_data.py',
 'author_uncorrected.py':'https://raw.githubusercontent.com/jesswhitts/AML-scAtlas/revised/1_Initial_QC/4_UncorrectedAnalysis/uncorrected_analysis.py',
 'author_preprocessing.ipynb':'https://raw.githubusercontent.com/jesswhitts/AML-scAtlas/revised/1_Initial_QC/1_SampleQC/example_preprocessing.ipynb',
 'lasry_fulltext.xml':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC9986885/fullTextXML',
 'vangalen_fulltext.xml':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC6515904/fullTextXML',
 'lasry_bioc.xml':'https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_xml/PMC9986885/unicode',
 'vangalen_bioc.xml':'https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_xml/PMC6515904/unicode',
 'MSigDB_Hallmark_2020.gmt':'https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName=MSigDB_Hallmark_2020',
}
records=[]
for name,url in SOURCES.items():
 p=ROOT/'inputs'/name
 if name in ['lasry_fulltext.xml','vangalen_fulltext.xml','lasry_bioc.xml'] and not p.exists():
  records.append(dict(file=name,url=url,status='previous_attempt_failed',error='EuropePMC HTTP 500 or NCBI BioC HTTP 429; no additional automatic retries'))
  continue
 try:
  if not p.exists():
   req=urllib.request.Request(url,headers={'User-Agent':'scAtlas-reanalysis/1.0'})
   with urllib.request.urlopen(req,timeout=120) as r: data=r.read()
   p.write_bytes(data)
  records.append(dict(file=name,url=url,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),status='retrieved',retrieved_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))
  print(name,p.stat().st_size,flush=True)
 except Exception as e:
  records.append(dict(file=name,url=url,status='failed',error=str(e)))
  print(name,str(e),flush=True)
(ROOT/'provenance'/'public_sources.json').write_text(json.dumps(records,indent=2))
