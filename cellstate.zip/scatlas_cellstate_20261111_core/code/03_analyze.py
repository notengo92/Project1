"""Donor-level analyses; design fixed in report/data_capability_and_design.md."""
from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy.stats import wilcoxon,spearmanr
from statsmodels.stats.multitest import multipletests
R=Path(__file__).resolve().parents[1];T=R/'tables'
model=json.load(open(R/'inputs/model_user_specification.json'));G=model['genes'];B=np.array([model['coefficients'][g] for g in G]);rng=np.random.default_rng(20261111)
don=pd.read_csv(T/'donor_inventory.csv',keep_default_na=False).set_index('donor_id')
nums=['n_cells','library_counts']+[g+x for g in G for x in ['_counts','_detected_cells']]
samples=pd.read_csv(T/'sample_inventory.csv',keep_default_na=False)
representative=samples.sort_values(['donor_id','n_cells','Sample'],ascending=[True,False,True]).drop_duplicates('donor_id').Sample
samples['selected_for_single_sample_sensitivity']=samples.Sample.isin(representative);samples.to_csv(T/'sample_selection_sensitivity.csv',index=False)
def aggregate(level,representative_only=False):
 s=pd.read_csv(R/'intermediate'/f'{level}_sample_groups.csv',keep_default_na=False)
 if representative_only:s=s[s.Sample.isin(representative)]
 x=s.groupby(['donor_id','state'],observed=True)[nums].sum().reset_index().join(don[['Study','disease','Main Age Group','assay']],on='donor_id')
 rows=[]
 for g in G:
  q=x[['donor_id','state','Study','disease','Main Age Group','assay','n_cells','library_counts']].copy();q['gene']=g;q['gene_counts']=x[g+'_counts'];q['detected_cells']=x[g+'_detected_cells'];q['detection_fraction']=q.detected_cells/q.n_cells;q['cpm']=1e6*q.gene_counts/q.library_counts;q['log2cpm1']=np.log2(1+q.cpm);rows.append(q)
 return pd.concat(rows,ignore_index=True),x
broad,bx=aggregate('broad');fine,fx=aggregate('fine');single,_=aggregate('broad',True)
broad.to_csv(T/'donor_broad_expression.csv',index=False);fine.to_csv(T/'donor_hspc_expression.csv',index=False)
excluded_studies=['setty_2019','stetson_2021']
inclusion=don.copy();inclusion['count_analysis_eligible']=~inclusion.Study.isin(excluded_studies);inclusion['reason']=np.where(inclusion.count_analysis_eligible,'Count-compatible raw.X; X inversion agrees','raw.X shows quantization versus X-derived pre-normalization values; original count scale unresolved');inclusion.to_csv(T/'analysis_donor_inclusion.csv')
broad=broad[~broad.Study.isin(excluded_studies)];fine=fine[~fine.Study.isin(excluded_studies)];single=single[~single.Study.isin(excluded_studies)];bx=bx[~bx.Study.isin(excluded_studies)];fx=fx[~fx.Study.isin(excluded_studies)]
def profile(d):
 return d[d.n_cells>=50].groupby(['disease','state','gene'],observed=True).agg(n_donors=('donor_id','nunique'),median_log2cpm1=('log2cpm1','median'),q25_log2cpm1=('log2cpm1',lambda x:x.quantile(.25)),q75_log2cpm1=('log2cpm1',lambda x:x.quantile(.75)),median_detection=('detection_fraction','median'),n_donors_detected=('gene_counts',lambda x:int((x>0).sum()))).reset_index()
profile(broad).to_csv(T/'broad_expression_summary.csv',index=False);profile(fine).to_csv(T/'hspc_expression_summary.csv',index=False)
def contrasts(data,a,b,threshold=50,subset='all_AML',label='primary',boot=3000):
 d=data[(data.n_cells>=threshold)&(data.disease!='normal')]
 if subset=='adult':d=d[d['Main Age Group']=='adult']
 elif subset=='exclude_lasry':d=d[d.Study!='lasry_2022']
 elif subset=='healthy':d=data[(data.n_cells>=threshold)&(data.disease=='normal')]
 elif subset.startswith('study:'):d=d[d.Study==subset[6:]]
 result=[];individual=[]
 for g in G:
  p=d[(d.gene==g)&d.state.isin([a,b])].pivot(index='donor_id',columns='state',values='log2cpm1').reindex(columns=[a,b]).dropna()
  delta=(p[a]-p[b]).to_numpy();n=len(delta)
  if n:
   ci=np.quantile(np.median(rng.choice(delta,(boot,n),replace=True),axis=1),[.025,.975])
   if subset.startswith('study:') and n<5:ci=np.array([np.nan,np.nan])
   pv=wilcoxon(delta,zero_method='wilcox',alternative='two-sided',method='auto').pvalue if np.any(delta!=0) and n>=8 else (1. if n>=8 else np.nan)
   result.append(dict(family=label,comparison=a+' minus '+b,subset=subset,min_cells=threshold,gene=g,n_donors=n,n_studies=don.loc[p.index].Study.nunique(),median_delta=float(np.median(delta)),ci_low=ci[0],ci_high=ci[1],n_positive=int((delta>0).sum()),n_negative=int((delta<0).sum()),n_tied=int((delta==0).sum()),p=pv))
   for donor_id,aa,bb,dd in zip(p.index,p[a],p[b],delta):individual.append(dict(comparison=a+' minus '+b,gene=g,donor_id=donor_id,Study=don.loc[donor_id,'Study'],a_log2cpm1=aa,b_log2cpm1=bb,delta=dd))
 return pd.DataFrame(result),pd.DataFrame(individual)
main=[];points=[]
for a,b in [('HSPC','CD14+ Mono'),('HSPC','GMP')]:
 q,p=contrasts(broad,a,b);main.append(q);points.append(p)
main=pd.concat(main,ignore_index=True);main['q_BH']=multipletests(main.p,method='fdr_bh')[1];main.to_csv(T/'primary_paired_contrasts.csv',index=False)
pd.concat(points,ignore_index=True).to_csv(T/'primary_paired_donor_values.csv',index=False)
q,p=contrasts(fine,'HSC-like','GMP-like',label='secondary_HSPC_reference');q['q_BH']=multipletests(q.p,method='fdr_bh')[1];q.to_csv(T/'secondary_hspc_contrasts.csv',index=False);p.to_csv(T/'secondary_hspc_donor_values.csv',index=False)
sens=[];study=[]
for a,b in [('HSPC','CD14+ Mono'),('HSPC','GMP')]:
 for th,subset,dd,label in [(30,'all_AML',broad,'threshold30'),(100,'all_AML',broad,'threshold100'),(50,'adult',broad,'adult'),(50,'exclude_lasry',broad,'exclude_lasry'),(50,'all_AML',single,'largest_sample_only'),(50,'healthy',broad,'healthy_reference')]:
  q,_=contrasts(dd,a,b,th,subset,label);sens.append(q)
 for st in sorted(don.Study.unique()):
  q,_=contrasts(broad,a,b,50,'study:'+st,'study_descriptive',boot=2000)
  if len(q):study.append(q)
pd.concat(sens,ignore_index=True).to_csv(T/'sensitivity_paired_contrasts.csv',index=False)
pd.concat(study,ignore_index=True).to_csv(T/'study_paired_contrasts.csv',index=False)
# Patient-level transferred expression descriptor. All retained genes define CPM denominator.
allx=bx.groupby('donor_id')[nums].sum().join(don[['Study','disease','Main Age Group']])
C=np.column_stack([allx[g+'_counts']/allx.library_counts*1e6 for g in G]);L=np.log2(1+C);aml=np.asarray(allx.disease!='normal');mu=L[aml].mean(0);sd=L[aml].std(0,ddof=0);assert (sd>0).all()
score=lambda c: ((np.log2(1+np.asarray(c))-mu)/sd)@B
allx['transferred_expression_score']=score(C)
for j,g in enumerate(G):allx[g+'_cpm']=C[:,j];allx[g+'_z']=(L[:,j]-mu[j])/sd[j];allx[g+'_score_contribution']=allx[g+'_z']*B[j]
allx.to_csv(T/'donor_transferred_scores.csv')
pd.DataFrame({'gene':G,'coefficient':B,'reference_mean_log2cpm1':mu,'reference_sd_log2cpm1_ddof0':sd,'reference_n_AML_donors':int(aml.sum())}).to_csv(T/'score_reference_parameters.csv',index=False)
# Check linear mixture identity before interpreting log transformation or scores.
maxerr=0.
for di,z in bx.groupby('donor_id'):
 cc=np.column_stack([z[g+'_counts']/z.library_counts*1e6 for g in G]);recon=(cc*(z.library_counts/z.library_counts.sum()).to_numpy()[:,None]).sum(0)
 target=allx.loc[di,[g+'_cpm' for g in G]].to_numpy(float);maxerr=max(maxerr,float(np.max(np.abs(recon-target))))
assert maxerr<1e-7
state_scores=bx.copy();scpm=np.column_stack([bx[g+'_counts']/bx.library_counts*1e6 for g in G]);state_scores['transferred_state_expression_score']=score(scpm);state_scores.to_csv(T/'donor_state_scores.csv',index=False)
# Common-state subset with no missing-state imputation; study-specific leave-one-donor-out composition reference.
eligible=bx[(bx.disease!='normal')&(bx.n_cells>=50)&bx.state.isin(['HSPC','CD14+ Mono'])]
ids=eligible.groupby('donor_id').state.nunique();ids=ids[ids==2].index
elig=don.copy();elig['eligible_two_states_50']=elig.index.isin(ids);elig.to_csv(T/'two_state_eligibility.csv')
mix=[];corr=[]
def corr_ci(x,y):
 x=np.asarray(x);y=np.asarray(y);n=len(x)
 if np.ptp(x)==0 or np.ptp(y)==0:return np.nan,np.nan,np.nan
 rho=spearmanr(x,y).statistic;vals=[]
 for _ in range(2000):
  ii=rng.integers(0,n,n)
  if np.ptp(x[ii]) and np.ptp(y[ii]):vals.append(spearmanr(x[ii],y[ii]).statistic)
 lo,hi=np.quantile(vals,[.025,.975]);return rho,lo,hi
for st,z in eligible[eligible.donor_id.isin(ids)].groupby('Study'):
 donors=sorted(z.donor_id.unique());n=len(donors)
 if n<8:continue
 h=z[z.state=='HSPC'].set_index('donor_id').loc[donors];m=z[z.state=='CD14+ Mono'].set_index('donor_id').loc[donors]
 hc=np.column_stack([h[g+'_counts']/h.library_counts*1e6 for g in G]);mc=np.column_stack([m[g+'_counts']/m.library_counts*1e6 for g in G])
 w=(h.library_counts/(h.library_counts+m.library_counts)).to_numpy()[:,None]
 observed=score(w*hc+(1-w)*mc);fixed=score(.5*hc+.5*mc)
 href=(hc.sum(0)-hc)/(n-1);mref=(mc.sum(0)-mc)/(n-1);comp=score(w*href+(1-w)*mref)
 comp_constant=score(w*hc.mean(0)+(1-w)*mc.mean(0))
 cc=pd.DataFrame({'donor_id':donors,'Study':st,'n_study_donors':n,'hspc_RNA_fraction_two_states':w[:,0],'hspc_cell_fraction_two_states':(h.n_cells/(h.n_cells+m.n_cells)).to_numpy(),'two_state_fraction_all_captured_RNA':((h.library_counts+m.library_counts)/allx.loc[donors,'library_counts']).to_numpy(),'score_observed_two_state':observed,'score_fixed_50_50_RNA':fixed,'score_composition_reference_LOO':comp,'score_all_captured_cells':allx.loc[donors,'transferred_expression_score'].to_numpy(),'score_HSPC':score(hc),'score_CD14_Mono':score(mc)})
 cc['score_composition_reference_constant']=comp_constant
 mix.append(cc)
 for x,y in [('score_observed_two_state','score_fixed_50_50_RNA'),('score_observed_two_state','score_composition_reference_LOO'),('score_observed_two_state','score_composition_reference_constant'),('score_HSPC','score_CD14_Mono'),('score_all_captured_cells','score_fixed_50_50_RNA')]:
  rho,lo,hi=corr_ci(cc[x],cc[y]);corr.append(dict(Study=st,n_donors=n,x=x,y=y,spearman_rho=rho,ci_low=lo,ci_high=hi))
pd.concat(mix,ignore_index=True).to_csv(T/'two_state_score_decomposition.csv',index=False) if mix else None
pd.DataFrame(corr).to_csv(T/'two_state_score_correlations.csv',index=False)
# Study-level coverage and panel detection, including zeros, not exclusion gates.
d=allx.reset_index();rows=[]
for (st,dis),z in d.groupby(['Study','disease']):
 for g in G:rows.append(dict(Study=st,disease=dis,gene=g,n_donors=len(z),donors_detected=int((z[g+'_counts']>0).sum()),total_gene_counts=int(z[g+'_counts'].sum()),pooled_cell_detection=z[g+'_detected_cells'].sum()/z.n_cells.sum(),median_donor_detection=(z[g+'_detected_cells']/z.n_cells).median()))
pd.DataFrame(rows).to_csv(T/'study_gene_detection.csv',index=False)
(R/'provenance/analysis_checks.json').write_text(json.dumps({'seed':20261111,'primary_tests':len(main),'maximum_CPM_mixture_reconstruction_error':maxerr,'model_genes':G,'AML_donors_score_reference':int(aml.sum()),'common_two_state_AML_donors':len(ids),'two_state_studies_n_ge8':len(mix),'main_min_cells':50,'excluded_count_studies':excluded_studies,'included_cells':int(allx.n_cells.sum()),'included_healthy_donors':int((~aml).sum())},indent=2))
print(main.to_string(index=False));print(pd.DataFrame(corr).to_string(index=False));print('Analysis complete')
