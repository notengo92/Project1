from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import spearmanr
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];T=R/'tables';rng=np.random.default_rng(20261111)
s=pd.read_csv(T/'donor_transferred_scores.csv');s=s[(s.Study=='van_galen_2019')&(s.disease!='normal')].set_index('donor_id')
c=pd.read_csv(T/'donor_celltype_coverage.csv');c=c[c.donor_id.isin(s.index)].pivot(index='donor_id',columns='Author Cell Type',values='n_cells').fillna(0).reindex(s.index)
fractions=c.div(c.sum(axis=1),axis=0);s['HSPC_fraction']=fractions['HSPC'];s['CD14_Mono_fraction']=fractions['CD14+ Mono'];s['lymphoid_fraction']=fractions.reindex(columns=['T','B','NK'],fill_value=0).sum(axis=1)
state=pd.read_csv(T/'donor_state_scores.csv');state=state[(state.state=='HSPC')&(state.n_cells>=50)].set_index('donor_id');s=s.join(state[['transferred_state_expression_score']].rename(columns={'transferred_state_expression_score':'HSPC_expression_score'}))
s.to_csv(T/'comparable_vangalen_donor_composition.csv');rows=[]
for score in ['transferred_expression_score','HSPC_expression_score']:
 for frac in ['HSPC_fraction','CD14_Mono_fraction','lymphoid_fraction']:
  q=s[[score,frac]].dropna();x=q[score].to_numpy();y=q[frac].to_numpy();n=len(q)
  rho,p=spearmanr(x,y);rr=[]
  for _ in range(3000):
   i=rng.integers(0,n,n)
   if np.ptp(x[i]) and np.ptp(y[i]):rr.append(spearmanr(x[i],y[i]).statistic)
  lo,hi=np.quantile(rr,[.025,.975]);rows.append(dict(Study='van_galen_2019',score=score,composition=frac,n_donors=n,rho=rho,ci_low=lo,ci_high=hi,p=p))
res=pd.DataFrame(rows);res['q_BH_6']=multipletests(res.p,method='fdr_bh')[1];res.to_csv(T/'comparable_vangalen_associations.csv',index=False)
fig,axs=plt.subplots(2,3,figsize=(11,6),layout='constrained')
for ax,(_,row) in zip(axs.ravel(),res.iterrows()):
 q=s[[row.score,row.composition]].dropna();ax.scatter(q[row.score],q[row.composition],s=26,c='#367b8d');ax.set(xlabel='All captured cells score' if row.score=='transferred_expression_score' else 'HSPC within-state score',ylabel=row.composition.replace('_',' '),title=f'n={row.n_donors}, ρ={row.rho:.2f}\n95% CI [{row.ci_low:.2f}, {row.ci_high:.2f}]')
fig.suptitle('Unenriched AML subset: observed composition and expression scores',fontsize=12)
for ext in ['png','pdf']:fig.savefig(R/'figures'/f'SC8_comparable_composition.{ext}',dpi=220,bbox_inches='tight')
print(res.to_string(index=False))
