#!/usr/bin/env bash
set -euo pipefail
RUN_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN=/home/a3020/miniconda3/envs/py3_11/bin/python
export PYTHONDONTWRITEBYTECODE=1
export OPENBLAS_NUM_THREADS=4
export OMP_NUM_THREADS=4
export MPLCONFIGDIR=/tmp/scatlas-core-mpl
# Public sources are already cached. To refresh missing sources, run 00_sources.py explicitly with network access.
for step in 01_inventory 05_matrix_audit 06_source_audit 02_aggregate 03_analyze 04_figures 07_comparable_composition 08_pathways 09_report 10_validate; do
  "$PYTHON_BIN" -u "$RUN_ROOT/code/$step.py" > "$RUN_ROOT/logs/$step.log" 2>&1
done
