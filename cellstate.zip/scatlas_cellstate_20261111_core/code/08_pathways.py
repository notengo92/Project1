"""Exploratory, panel-excluded Hallmark expression associations within donor states."""
from pathlib import Path
import json
import numpy as np,pandas as pd,scipy.sparse as sp
from scipy.stats import spearmanr
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];T=R/'tables';rng=np.random.default_rng(20261111)
panel=set(json.load(open(R/'inputs/model_user_specification.json'))['genes'])
sets={}
for line in (R/'inputs/MSigDB_Hallmark_2020.gmt').read_text().splitlines():
 a=line.split('\t');name=a[0].upper().replace(' ','_')
 if any(k in name for k in ['MTORC1_SIGNALING','CHOLESTEROL_HOMEOSTASIS']):sets[name]=sorted(set(a[2:])-{''})
assert len(sets)==2,sets
v=pd.read_csv(R/'intermediate/gene_metadata.csv.gz');meta=pd.read_csv(R/'intermediate/broad_sample_groups.csv',keep_default_na=False);mat=sp.load_npz(R/'intermediate/broad_sample_counts.npz')
don=pd.read_csv(T/'analysis_donor_inclusion.csv').set_index('donor_id');scores=pd.read_csv(T/'donor_state_scores.csv').set_index(['donor_id','state'])
selected_genes=sorted(set.union(*[set(s) for s in sets.values()])-panel);present=[g for g in selected_genes if (v.gene_symbol==g).any()]
# Sum duplicate symbol mappings before computing expression if any occur.
columns=[]
for g in present:columns.append(np.asarray(mat[:,np.flatnonzero(v.gene_symbol==g)].sum(axis=1)).ravel())
M=np.column_stack(columns)
meta=pd.concat([meta,pd.DataFrame(M,columns=present,index=meta.index)],axis=1)
meta=meta[meta.donor_id.isin(don[(don.count_analysis_eligible)&(don.disease!='normal')].index)]
dd=meta.groupby(['donor_id','state','Study'],observed=True)[['n_cells','library_counts']+present].sum().reset_index();dd=dd[(dd.n_cells>=50)&dd.state.isin(['HSPC','CD14+ Mono'])]
coverage=[];refs=[];long=[]
for state,d in dd.groupby('state'):
 E=np.log2(1+d[present].to_numpy()/d.library_counts.to_numpy()[:,None]*1e6);mu=E.mean(0);sd=E.std(0,ddof=0)
 for j,g in enumerate(present):refs.append(dict(state=state,gene=g,n_reference_donors=len(d),mean_log2cpm1=mu[j],sd_log2cpm1=sd[j]))
 for name,gs in sets.items():
  usable=[g for g in present if g in gs and sd[present.index(g)]>0];jj=[present.index(g) for g in usable]
  coverage.append(dict(state=state,pathway=name,n_original=len(gs),panel_overlap=';'.join(sorted(set(gs)&panel)),missing_from_object=';'.join(sorted(set(gs)-set(v.gene_symbol))),zero_variance_genes=';'.join(g for g in present if g in gs and sd[present.index(g)]==0),used_genes=';'.join(usable),n_usable_after_panel_removal=len(usable),coverage_before_panel_removal=len(set(gs)&set(v.gene_symbol))/len(gs)))
  assert len(usable)>=.7*len(gs),'Insufficient gene set coverage'
  q=d[['donor_id','state','Study','n_cells']].copy();q['pathway']=name;q['pathway_expression_score']=((E[:,jj]-mu[jj])/sd[jj]).mean(1);q['five_gene_state_score']=[scores.loc[(di,state),'transferred_state_expression_score'] for di in q.donor_id];long.append(q)
long=pd.concat(long,ignore_index=True);long.to_csv(T/'pathway_donor_state_scores.csv',index=False)
pd.DataFrame(coverage).to_csv(T/'pathway_gene_coverage.csv',index=False);pd.DataFrame(refs).to_csv(T/'pathway_reference_parameters.csv',index=False)
(R/'inputs/pathways_used.json').write_text(json.dumps(sets,indent=2))
rows=[]
for (state,study,pathway),d in long.groupby(['state','Study','pathway']):
 if len(d)<8:continue
 x=d.five_gene_state_score.to_numpy();y=d.pathway_expression_score.to_numpy();n=len(x);rho,p=spearmanr(x,y);rr=[]
 for _ in range(2000):
  i=rng.integers(0,n,n)
  if np.ptp(x[i]) and np.ptp(y[i]):rr.append(spearmanr(x[i],y[i]).statistic)
 lo,hi=np.quantile(rr,[.025,.975]);rows.append(dict(state=state,Study=study,pathway=pathway,n_donors=n,rho=rho,ci_low=lo,ci_high=hi,p=p))
res=pd.DataFrame(rows);res['q_BH_all_exploratory']=multipletests(res.p,method='fdr_bh')[1];res.to_csv(T/'pathway_study_associations.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(13,6.5),layout='constrained')
for ax,pathway in zip(axs,sorted(res.pathway.unique())):
 q=res[res.pathway==pathway].sort_values(['state','Study']).reset_index(drop=True)
 for i,row in q.iterrows():ax.errorbar(row.rho,i,xerr=[[row.rho-row.ci_low],[row.ci_high-row.rho]],fmt='o',color='#326a8b' if row.state=='HSPC' else '#bd682c',capsize=2)
 ax.axvline(0,ls='--',color='gray',lw=.8);ax.set(yticks=range(len(q)),yticklabels=[f'{row.state} / {row.Study} (n={row.n_donors})' for row in q.itertuples()],xlim=(-1.05,1.05),xlabel='Spearman ρ (conditional bootstrap 95% CI)',title=pathway.replace('HALLMARK_','').replace('_',' '));ax.invert_yaxis()
fig.suptitle('Exploratory within-state expression programs; five model genes removed from gene sets',fontsize=11)
for ext in ['png','pdf']:fig.savefig(R/'figures'/f'SC9_pathway_expression_associations.{ext}',dpi=220,bbox_inches='tight')
print(pd.DataFrame(coverage).to_string(index=False));print(res.to_string(index=False))
