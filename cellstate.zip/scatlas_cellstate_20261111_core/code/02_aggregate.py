"""Stream read-only CSR raw counts; preserve sample-level whole-gene pseudobulks."""
from pathlib import Path
import json,time
import h5py,numpy as np,pandas as pd,scipy.sparse as sp
from anndata.io import read_elem
R=Path(__file__).resolve().parents[1]
P='/data/scAtlas/AML_scAtlas_CELLxGENE.h5ad'
genes=json.load(open(R/'inputs/model_user_specification.json'))['genes']
with h5py.File(P,'r') as f:
 o=read_elem(f['obs']);v=read_elem(f['var']);n=len(o);p=len(v)
 gi=np.array([np.flatnonzero(v.gene_symbol==g)[0] for g in genes])
 raw=f['raw/X'];indptr=raw['indptr'][:]
 groupings={};mats={};group_ids={}
 for level,col in [('broad','Author Cell Type'),('fine','HSPC Cell Type')]:
  eligible=np.ones(n,bool) if level=='broad' else np.asarray(o['Author Cell Type']=='HSPC')
  keys=pd.MultiIndex.from_frame(o.loc[eligible,['Sample',col]])
  codes,unique=pd.factorize(keys,sort=True)
  ids=np.full(n,-1,np.int32);ids[eligible]=codes;group_ids[level]=ids
  meta=unique.to_frame(index=False);meta.columns=['Sample','state'];meta['group_id']=np.arange(len(meta))
  sm=o.groupby('Sample',observed=True)[['donor_id','Study','disease','Main Age Group','assay']].first()
  meta=meta.join(sm,on='Sample');meta['n_cells']=np.bincount(codes,minlength=len(meta))
  meta.to_csv(R/'intermediate'/f'{level}_sample_groups.csv',index=False);groupings[level]=meta
  mats[level]=np.zeros((len(meta),p),np.float64)
  print(level,len(meta),flush=True)
 cell_genes=np.zeros((n,len(genes)),np.float32);lib=np.zeros(n,np.float64)
 audit={'nnz_checked':0,'nonfinite':0,'negative':0,'noninteger':0,'stored_zero':0,'max_value':0,'n_cells':n,'n_genes':p,'matrix':'raw.X'}
 start=time.time()
 for lo in range(0,n,8192):
  hi=min(lo+8192,n);a,b=indptr[lo],indptr[hi]
  values=raw['data'][a:b];indices=raw['indices'][a:b]
  audit['nnz_checked']+=len(values);audit['nonfinite']+=int((~np.isfinite(values)).sum());audit['negative']+=int((values<0).sum());audit['noninteger']+=int((values!=np.rint(values)).sum());audit['stored_zero']+=int((values==0).sum());audit['max_value']=max(audit['max_value'],float(values.max(initial=0)))
  assert audit['nonfinite']==audit['negative']==audit['noninteger']==0,'raw.X failed count validation'
  c=sp.csr_matrix((values.astype(np.float64),indices,indptr[lo:hi+1]-a),shape=(hi-lo,p));c.sum_duplicates()
  cell_genes[lo:hi]=c[:,gi].toarray();lib[lo:hi]=np.asarray(c.sum(axis=1)).ravel()
  for level,ids in group_ids.items():
   cc=ids[lo:hi];ok=cc>=0
   h=sp.csr_matrix((np.ones(ok.sum()),(cc[ok],np.flatnonzero(ok))),shape=(len(mats[level]),hi-lo))
   z=(h@c).tocoo();mats[level][z.row,z.col]+=z.data
  if lo//8192%10==0:print(f'{hi}/{n} cells, {time.time()-start:.1f}s',flush=True)
 audit['zero_library_cells']=int((lib==0).sum());audit['total_counts']=float(lib.sum())
 assert audit['zero_library_cells']==0,'Zero-library cells require explicit exclusion rule'
 for level,mat in mats.items():
  sp.save_npz(R/'intermediate'/f'{level}_sample_counts.npz',sp.csr_matrix(mat.astype(np.int64)))
  meta=groupings[level];meta['library_counts']=mat.sum(axis=1);ids=group_ids[level];ok=ids>=0
  for j,g in enumerate(genes):
   meta[g+'_counts']=mat[:,gi[j]]
   meta[g+'_detected_cells']=np.bincount(ids[ok],weights=cell_genes[ok,j]>0,minlength=len(meta)).astype(int)
  meta.to_csv(R/'intermediate'/f'{level}_sample_groups.csv',index=False)
  assert mat.sum()==lib[ok].sum()
 np.savez_compressed(R/'intermediate'/'cell_panel_counts.npz',counts=cell_genes,library=lib,genes=np.array(genes))
 (R/'provenance'/'raw_full_validation.json').write_text(json.dumps(audit,indent=2))
 print(json.dumps(audit,indent=2),flush=True)
