from pathlib import Path
import json,html
import numpy as np,pandas as pd
R=Path(__file__).resolve().parents[1];T=R/'tables';P=R/'report'
def table(df):
 def fmt(x):
  if isinstance(x,float):return f'{x:.3g}'
  return str(x).replace('|','/')
 return '| '+' | '.join(df.columns)+' |\n|'+'|'.join(['---']*len(df.columns))+'|\n'+'\n'.join('| '+' | '.join(fmt(v) for v in row)+' |' for row in df.itertuples(index=False,name=None))+'\n'
primary=pd.read_csv(T/'primary_paired_contrasts.csv');fine=pd.read_csv(T/'secondary_hspc_contrasts.csv');mix=pd.read_csv(T/'two_state_score_correlations.csv');comp=pd.read_csv(T/'comparable_vangalen_associations.csv');path=pd.read_csv(T/'pathway_study_associations.csv');checks=json.load(open(R/'provenance/analysis_checks.json'));inventory=json.load(open(R/'provenance/inventory.json'))
scores=pd.read_csv(T/'donor_transferred_scores.csv');genes=json.load(open(R/'inputs/model_user_specification.json'))['genes'];scores['n_panel_genes_zero']=(scores[[g+'_counts' for g in genes]]==0).sum(axis=1);scores['panel_total_counts']=scores[[g+'_counts' for g in genes]].sum(axis=1);scores[['donor_id','Study','disease','n_cells','library_counts','panel_total_counts','n_panel_genes_zero']].to_csv(T/'score_count_coverage.csv',index=False)
markers=pd.read_csv(T/'hspc_marker_donor_expression.csv');markers=markers[(markers.disease!='normal')&markers.state.isin(['HSC-like','GMP-like'])];rows=[]
for g in ['CD34','GATA2','MPO','LYZ']:
 q=markers.pivot(index='donor_id',columns='state',values=g).dropna();delta=q['HSC-like']-q['GMP-like'];rows.append(dict(gene=g,n_paired=len(q),median_HSClike_minus_GMPlike=delta.median(),n_positive=int((delta>0).sum()),n_negative=int((delta<0).sum())))
pd.DataFrame(rows).to_csv(T/'hspc_marker_paired_audit.csv',index=False)
main=primary[primary.comparison=='HSPC minus CD14+ Mono'][['gene','n_donors','median_delta','ci_low','ci_high','n_positive','n_negative','q_BH']].copy()
main.columns=['基因','配对供者','中位差','95%CI下限','95%CI上限','HSPC较高人数','Mono较高人数','BH_q']
text='''# scAtlas 五基因细胞来源分析：结果与解释

本次结果支持五基因包含不同细胞状态的转录信息，尤其BCAT1的祖细胞偏向与ALDH2的单核/树突细胞偏向。数据不支持把整个加权评分直接称为统一的干性指标、BCAA代谢通量或已验证的单细胞预后风险。

## 实际纳入与数据含义

本地CELLxGENE对象含748679个细胞、223个样本、207个donor_id，来自20项研究；其中159位AML供者及48位健康供者。对象哈希与本地提供的SHA256一致。逐块检查raw.X的1348581602个存储项，无负数、非整数或非有限数，无零文库细胞。作者早期代码的raw槽含义与CELLxGENE导出不同，因此还核查了当前对象schema、X与raw的数值关系。

Setty和Stetson的X反推值与整数raw存在取整差异，原始量化来源尚未闭合；这两项研究保留在库存和中间汇总，不进入主要计数尺度结果。最终主要分析为717809个细胞、216个样本、200位供者（155 AML、45健康）、18项研究。AML年龄组为成人95、儿童49、未知11。人数按donor_id归并，16位原始供者的重复样本没有被当作独立患者；另做最大样本敏感性检查。没有根据表达方向、P值或ELN缺失筛选患者。

CPM分母是当前导出对象的21588个基因，不能当作完整原始测序文库。表达分析是供者×状态计数求和后的log2(1+CPM)，检出比例也是先按供者计算再汇总。主阈值50细胞，另查30/100。全部逐细胞来源和作者注释均保留；统计单位不是细胞。healthy与AML标签表示样本来源，不表示逐细胞恶性真值。

## 五基因主要在哪里表达？

- **BCAT1**：在AML来源HSPC/CMP等祖细胞区室较高。132位可估计HSPC供者的检出比例中位数约25.8%；该基因并非每个HSPC细胞均可检出。
- **ALDH2**：在CD14+单核细胞、ProMono及树突细胞区室较高。CD14+ Mono有90位、cDC有36位供者支持描述；其分布与BCAT1并不一致。
- **ACADSB**：表达较广，T/NK、CMP/HSPC中均有信号；在HSPC相对单核细胞的配对比较中偏高，但模型系数为负，必须保留其反向贡献。
- **ACAT2**：红系、ProMono、T及HSPC等多类细胞均有表达，不是单一原始细胞标志。
- **OXCT1**：T/B/NK及多个祖细胞/红系区室均有表达，单核细胞相对低；不能将其全部解释为AML原始细胞来源。

这些“较高”指当前计数背景下的相对表达，不是细胞总转录产量或某类细胞对真实骨髓的贡献份额。ProB等少数供者区室也绘出，但不以其极端中位值概括总体来源。见SC2及broad_expression_summary.csv；图中空白表示没有达到细胞数门槛的供者，不是补零表达。

## 哪些状态差异有供者级支持？

73位AML供者、10项研究同时具有足量HSPC和CD14+ Mono。下表为同一供者HSPC减Mono的log2(1+CPM)差；它含+1伪计数，不直接等同于原始表达倍数。区间为供者bootstrap，P来自配对Wilcoxon；BH在两组主要对比×5基因共10项检验中控制。

'''+table(main)+'''
在至少5位配对供者的6项研究中，这5个基因的研究内中位方向均与总体一致。改变门槛至30/100细胞、限成人45位配对供者、去除Lasry、每供者只保留最大样本后，HSPC/Mono的主要方向保持。健康来源的17位配对供者也表现BCAT1偏HSPC、ALDH2偏Mono，提示这包含正常分化背景，不能据此宣称AML特异性。

HSPC与GMP比较有64位供者：ACADSB、ACAT2、BCAT1的中位差为约+0.25、+0.47、+0.55；ALDH2与OXCT1没有清晰差异（BH q约0.072与0.256）。这限制了把两基因概括成贯穿整个分化层级的单调变化。

HSPC内部的HSC-like/GMP-like比较有21位供者、9项研究。ACAT2和OXCT1在HSC-like中更低，中位差−0.39和−0.81，BH q=0.0011及0.00012。BCAT1在此更细层级仅有较小差异（+0.14，q约0.055）；ALDH2结果边界性，bootstrap下限为0，不能夸大。标记核查中21/21位供者的HSC-like均有更高CD34、更低MPO和LYZ，为这一参考映射对比提供表达支持，但不构成独立恶性认证。HSPC映射中的B/Plasma等标签未必符合成熟细胞典型标记，故只称“参考标签”，不据此改写作者大类或开展成熟细胞组成推断。

## 与bulk评分的联系能支持到什么程度？

本次采用用户确认的v28系数，不重新拟合。将155位AML供者的全捕获细胞pseudobulk log2(1+CPM)逐基因z标准化（ddof=0），再按指定权重加和；参考均值/SD和各基因贡献均保存。它是迁移表达评分，未复现原训练集的完整测量及预处理条件，也没有生存结局可用于校准。

全样本CPM可由状态CPM按测得文库比例加权精确重建，最大绝对误差低于6×10^-14。因此组成与状态内表达共同进入评分，在算术上不能把它们当作独立量。细胞比例也不等于RNA/计数贡献比例。

在共同有足量HSPC和CD14+ Mono、且研究内至少8位供者的4项研究中（合计48位），固定两状态1:1 RNA权重后，评分与观察两状态评分的Spearman相关为0.65、0.87、0.98、0.85；固定研究内状态表达、只改变RNA比例的描述量与观察评分相关为−0.35、0.13、−0.30、−0.03，区间均跨0。固定权重后仍有供者表达差异，但两评分共享输入，不能把高相关解读为已证明独立生物学机制。所选两状态仅覆盖各研究供者RNA的中位约42%–70%，最小个体仅约2.5%，不代表完整样本。LOO组成参考有自排除造成的反向数学依赖，原结果也保留，不能以其负相关作为组成效应证据。

在原文可确认未经富集的van Galen 16位AML供者中，全样本评分与HSPC、CD14+ Mono、T+B+NK比例的相关分别为−0.12、0.31、−0.02，区间均宽且跨0；HSPC内评分分析（15位）也未提供清晰关联。这里的证据是“不确定”，并非证明没有关联。该小队列中4位供者至少一个模型基因的汇总计数为0；全部155位AML供者中共6位存在这种情况，已单独标注，观测零值不等于模型基因缺失。

## 预设通路的探索及异质结果

在主结果之后补充原计划指定的mTORC1和胆固醇稳态表达集合，明确作为探索性分析。使用Enrichr的MSigDB_Hallmark_2020快照；从胆固醇集合移除ACAT2，从mTORC1集合移除BCAT1，并移除未测或零方差成员，最终分别使用68和185个基因。描述量为状态内供者标准化表达的平均，不称为代谢活性。

研究×状态×两通路共24项可估计关联进行统一BH校正。van Galen HSPC中胆固醇与mTORC1相关分别约0.79、0.73（q约0.012、0.027），Mumme单核细胞中mTORC1相关约0.82（q约0.031）；其他研究多数区间宽、跨0，Naldini HSPC方向为弱负。这些资料只支持部分研究/状态的转录共变，不支持普遍激活两条通路的结论。所有24项结果均交付，未只保留阳性项。

## 仍无法回答的问题

1. 没有可靠的全图谱逐细胞恶性真值，不能进行本模块定义下的恶性/非恶性对照或声称LSC特异性。作者健康来源比例规则和参考标签不能替代基因型证据。
2. 多数研究缺少可验证的逐样本分选映射；不能估计真实骨髓的细胞比例，也不能量化BeatAML评分/预后差异中由组成解释的百分比。
3. 仅有公开表达和元数据，不能检验生存预测、药敏、代谢通量或因果作用。没有通过调整study来声称消除了分选偏差。
4. 部分年龄/遗传资料仍未知，ELN为作者派生标签；没有将缺失信息补成确定类别或据此做临床增量验证。48与论文51名健康供者的差额尚无逐人清单能闭合；实际对象、样本映射和来源表差异全部保留。
5. 参考注释、不同技术的检测效率、CPM背景及状态内部异质性均带来限制。bootstrap是供者条件下的不确定性，不覆盖研究选择、标签误差、模型权重或取整来源不确定性。

## 文件索引

- data_capability_and_design.md：初始设计、技术排除、后续探索与变更理由。
- manuscript_results_CN.md / manuscript_results_EN.md：可供论文修改使用的结果段落。
- ../tables/primary_paired_contrasts.csv：主要效应、区间、人数及FDR；primary_paired_donor_values.csv为对应每位供者数值。
- ../tables/donor_broad_expression.csv、donor_hspc_expression.csv：所有导出供者的逐基因数值，包括技术排除者；使用时必须联结analysis_donor_inclusion.csv，不能把它们全部当主分析纳入者。
- ../tables/two_state_score_decomposition.csv、comparable_vangalen_associations.csv、pathway_study_associations.csv：所有组成/表达/通路结果及无关联项。
- ../intermediate/*_sample_counts.npz：全21588基因、样本×状态的稀疏汇总，行序见*_sample_groups.csv，列序见gene_metadata.csv.gz。
- ../results_browser.html 与 ../results_review.ipynb：浏览图表；Notebook使用已有py3_11内核，没有安装Notebook软件。

来源：图谱论文 https://pmc.ncbi.nlm.nih.gov/articles/PMC12893711/；van Galen方法 https://pmc.ncbi.nlm.nih.gov/articles/PMC6515904/；作者代码 https://github.com/jesswhitts/AML-scAtlas/tree/revised；基因集 https://maayanlab.cloud/Enrichr/ 与MSigDB。确切URL、下载状态、文件哈希见provenance目录。新增结果全部由本目录脚本计算。
'''
(P/'results_report.md').write_text(text)
cn='''基于AML scAtlas的供者级重分析显示，v28五基因信号具有异质的细胞来源。经矩阵尺度核查，主要分析纳入717809个细胞、155位AML及45位健康供者。在73位同时具有足量HSPC和CD14+单核细胞的AML供者中，BCAT1在HSPC中较高，中位配对log2(1+CPM)差为1.76（95% bootstrap CI 1.58–2.10），66/73位供者方向一致；ALDH2则偏向单核细胞，中位差为−2.19（−2.82至−1.73），63/73位方向一致。ACADSB、ACAT2及OXCT1在该对比中亦偏高于HSPC，但分布并非HSPC特异，且ACADSB保留模型中的负权重。上述方向在细胞数门槛、成人子集、去除最大研究及单样本敏感性分析中保持。在HSPC内部21位供者的参考映射状态对比中，ACAT2和OXCT1在HSC-like中的表达低于GMP-like，提示五基因并非统一的原始细胞程序。固定状态RNA权重的探索显示供者内状态表达差异仍进入迁移评分，但未经富集的van Galen子集（16位AML供者）未提供评分与所检验细胞比例的明确关联，区间较宽。去除模型基因重叠后的mTORC1及胆固醇稳态表达关联亦表现研究和状态异质性。因此，这些结果为bulk五基因评分提供细胞学背景，不能据此推断代谢通量、恶性细胞特异性或独立的预后效能。'''
cn=cn.replace('在该对比中亦偏高于HSPC','在该对比中也在HSPC中较高')
(P/'manuscript_results_CN.md').write_text(cn+'\n')
en='''Donor-level reanalysis of AML scAtlas revealed heterogeneous cellular origins of the five-gene v28 expression signal. Following matrix-scale assessment, the primary analysis included 717,809 cells from 155 AML and 45 healthy donors. Among 73 AML donors with at least 50 HSPCs and 50 CD14+ monocytes, BCAT1 expression was higher in HSPCs (median paired difference in log2[1+CPM], 1.76; 95% donor-bootstrap CI, 1.58–2.10; concordant direction in 66/73 donors), whereas ALDH2 was higher in monocytes (HSPC-minus-monocyte difference, −2.19; 95% CI, −2.82 to −1.73; concordant in 63/73). ACADSB, ACAT2 and OXCT1 were also higher in HSPCs in this contrast, although their broader distributions included other lineages; the negative model weight of ACADSB was retained. These directions persisted in cell-number, adult-only, study-exclusion and single-sample sensitivity analyses. Within the author-defined HSPC compartment, ACAT2 and OXCT1 were lower in HSC-like than GMP-like reference-mapped cells in 21 paired donors, arguing against a uniform primitive-cell program. Fixed-state RNA-weight analyses retained donor-level expression variation, but composition associations in the unenriched van Galen subset (16 AML donors) remained uncertain. Exploratory mTORC1 and cholesterol-homeostasis expression associations, excluding overlapping model genes, varied across studies and cell states. Thus, the analysis provides a cellular context for the bulk expression score without establishing metabolic flux, malignant-cell specificity, or prognostic performance in this atlas.'''
(P/'manuscript_results_EN.md').write_text(en+'\n')
# A portable browser and a notebook that read saved outputs, without any software installation.
figs=sorted((R/'figures').glob('*.png'))
browser='<!doctype html><html lang="zh"><meta charset="utf-8"><title>scAtlas results</title><style>body{font:16px system-ui;max-width:1250px;margin:35px auto;padding:15px;line-height:1.65}img{max-width:100%;height:auto}table{border-collapse:collapse}td,th{padding:7px;border:1px solid #ddd}pre{white-space:pre-wrap}a{color:#17687e}</style><h1>scAtlas 五基因分析</h1><p>'+html.escape(cn)+'</p><p><a href="report/results_report.md">完整结果报告</a> · <a href="report/data_capability_and_design.md">能力表与设计</a> · <a href="results_review.ipynb">Notebook</a></p>'+main.to_html(index=False)
for f in figs:browser+=f'<h2>{f.stem}</h2><p><a href="figures/{f.stem}.pdf">PDF</a></p><img loading="lazy" src="figures/{f.name}">'
browser+='</html>';(R/'results_browser.html').write_text(browser)
cells=[{'cell_type':'markdown','metadata':{},'source':['# scAtlas 五基因结果浏览\n',cn+'\n','统计与图形已由独立脚本计算。本Notebook只读取交付结果；选择已有py3_11内核运行。']},{'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':['from pathlib import Path\nimport pandas as pd\nfrom IPython.display import display, Image, Markdown\n','R = Path.cwd()\n','if not (R / "tables").exists():\n    R = R / "BCAA_AML_v28/singlecell/scatlas_cellstate_20261111"\n','assert (R / "tables").exists(), "请从本执行目录或项目根目录启动"\n','display(pd.read_csv(R / "tables/primary_paired_contrasts.csv"))\n']}]
for f in figs:cells.append({'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':[f'display(Image(filename=str(R / "figures/{f.name}")))\n']})
cells.append({'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':['display(pd.read_csv(R / "tables/comparable_vangalen_associations.csv"))\n','display(pd.read_csv(R / "tables/pathway_study_associations.csv"))\n','display(Markdown((R / "report/results_report.md").read_text()))\n']})
nb={'cells':cells,'metadata':{'kernelspec':{'display_name':'Python (py3_11)','language':'python','name':'py3_11'},'language_info':{'name':'python','version':'3.14.7'}},'nbformat':4,'nbformat_minor':5}
for i,c in enumerate(nb['cells']):c['id']=f'scatlas-{i:02d}'
(R/'results_review.ipynb').write_text(json.dumps(nb,ensure_ascii=False,indent=2))
print('Report, manuscript paragraphs, browser and notebook written')
