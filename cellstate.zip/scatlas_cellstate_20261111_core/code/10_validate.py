"""Integration checks on saved results and independent cell-to-group reconstruction."""
from pathlib import Path
import hashlib,json
import numpy as np,pandas as pd,scipy.sparse as sp
R=Path(__file__).resolve().parents[1];T=R/'tables'
inventory=json.load(open(R/'provenance/inventory.json'));audit=json.load(open(R/'provenance/raw_full_validation.json'));env=json.load(open(R/'provenance/input_environment.json'));G=json.load(open(R/'inputs/model_user_specification.json'))['genes']
assert env['input_sha256']==env['provided_sha256_file'].split()[0]
o=pd.read_csv(R/'intermediate/cell_metadata.csv.gz',usecols=['cell_id','Sample','donor_id','Author Cell Type','HSPC Cell Type'],keep_default_na=False)
c=np.load(R/'intermediate/cell_panel_counts.npz');assert len(o)==len(c['counts'])==inventory['n_cells'];assert c['library'].sum()==audit['total_counts']
v=pd.read_csv(R/'intermediate/gene_metadata.csv.gz');gi=[np.flatnonzero(v.gene_symbol==g)[0] for g in G]
for level,col in [('broad','Author Cell Type'),('fine','HSPC Cell Type')]:
 meta=pd.read_csv(R/'intermediate'/f'{level}_sample_groups.csv',keep_default_na=False);m=sp.load_npz(R/'intermediate'/f'{level}_sample_counts.npz');assert m.shape==(len(meta),len(v));assert np.array_equal(meta.group_id,np.arange(len(meta)))
 assert np.array_equal(m[:,gi].toarray(),meta[[g+'_counts' for g in G]].to_numpy());assert np.array_equal(np.asarray(m.sum(axis=1)).ravel(),meta.library_counts)
 eligible=np.ones(len(o),bool) if level=='broad' else np.asarray(o['Author Cell Type']=='HSPC')
 key=pd.MultiIndex.from_frame(meta[['Sample','state']]);cellkey=pd.MultiIndex.from_frame(o.loc[eligible,['Sample',col]]);ids=key.get_indexer(cellkey);assert (ids>=0).all()
 assert np.array_equal(np.bincount(ids,minlength=len(meta)),meta.n_cells)
 assert np.array_equal(np.bincount(ids,weights=c['library'][eligible],minlength=len(meta)),meta.library_counts)
 for j,g in enumerate(G):
  assert np.array_equal(np.bincount(ids,weights=c['counts'][eligible,j],minlength=len(meta)),meta[g+'_counts'])
  assert np.array_equal(np.bincount(ids,weights=c['counts'][eligible,j]>0,minlength=len(meta)),meta[g+'_detected_cells'])
inc=pd.read_csv(T/'analysis_donor_inclusion.csv');assert int(inc.count_analysis_eligible.sum())==200
scores=pd.read_csv(T/'donor_transferred_scores.csv');assert set(scores.donor_id)==set(inc[inc.count_analysis_eligible].donor_id)
assert scores.n_cells.sum()==717809;assert not scores.donor_id.duplicated().any()
params=pd.read_csv(T/'score_reference_parameters.csv').set_index('gene').loc[G];L=np.log2(1+scores[[g+'_cpm' for g in G]].to_numpy());expected=((L-params.reference_mean_log2cpm1.to_numpy())/params.reference_sd_log2cpm1_ddof0.to_numpy())@params.coefficient.to_numpy();np.testing.assert_allclose(expected,scores.transferred_expression_score,atol=1e-12)
points=pd.read_csv(T/'primary_paired_donor_values.csv');primary=pd.read_csv(T/'primary_paired_contrasts.csv')
for row in primary.itertuples():
 q=points[(points.comparison==row.comparison)&(points.gene==row.gene)];assert q.donor_id.nunique()==len(q)==row.n_donors;assert np.isclose(q.delta.median(),row.median_delta);assert row.n_positive+row.n_negative+row.n_tied==row.n_donors
assert len(primary)==10
path=pd.read_csv(T/'pathway_study_associations.csv');assert len(path)==24;assert (path.n_donors>=8).all()
coverage=pd.read_csv(T/'pathway_gene_coverage.csv')
for row in coverage.itertuples():assert not (set(row.used_genes.split(';'))&set(G))
nb=json.load(open(R/'results_review.ipynb'));assert nb['metadata']['kernelspec']['name']=='py3_11';assert all('id' in c for c in nb['cells'])
assert len(list((R/'figures').glob('*.pdf')))==len(list((R/'figures').glob('*.png')))==9
result={'status':'PASS','checks':['Input SHA256 matches supplied checksum','All raw entries scanned; no invalid values or empty libraries','Whole-gene sample group matrices agree with independent cell-panel/library reconstruction','Donor and study exclusions consistent','Transferred scores reconstructed from saved reference parameters','Paired effect medians and donor counts match saved individual data','Pathway members exclude all five model genes','Nine PDF/PNG pairs and notebook JSON present'],'input_cells':len(o),'analysis_cells':717809,'analysis_donors':200,'AML_donors':155}
(R/'provenance/validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
manifest=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and p.name!='file_manifest.csv' and 'logs' not in p.relative_to(R).parts:manifest.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)))
pd.DataFrame(manifest).to_csv(R/'provenance/file_manifest.csv',index=False)
