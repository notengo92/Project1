from pathlib import Path
import json
import numpy as np,pandas as pd,scipy.sparse as sp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
R=Path(__file__).resolve().parents[1];T=R/'tables';F=R/'figures'
G=json.load(open(R/'inputs/model_user_specification.json'))['genes'];rng=np.random.default_rng(20261111)
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'savefig.bbox':'tight'})
order=['HSPC','CMP','GMP','ProMono','CD14+ Mono','CD16+ Mono','cDC','pDC','MEP','Erythroid','ProB','B','Plasma','T','NK']
colors=dict(zip(order,sns.color_palette('tab20',len(order))))
def save(fig,name):
 fig.savefig(F/(name+'.png'),dpi=220);fig.savefig(F/(name+'.pdf'));plt.close(fig)
o=pd.read_csv(R/'intermediate/cell_metadata.csv.gz',usecols=['cell_id','donor_id','disease','Author Cell Type'],keep_default_na=False)
u=np.load(R/'intermediate/atlas_umap.npy');ix=rng.permutation(len(o))
fig,ax=plt.subplots(figsize=(9.4,5.5))
for st in order:
 ii=ix[o['Author Cell Type'].to_numpy()[ix]==st];ax.scatter(u[ii,0],u[ii,1],s=.3,color=colors[st],label=st,rasterized=True,linewidths=0)
ax.set(xlabel='Published scVI UMAP 1',ylabel='Published scVI UMAP 2',xticks=[],yticks=[],title='Atlas orientation: 748,679 cells / 207 donor IDs')
ax.legend(markerscale=7,bbox_to_anchor=(1.01,1),loc='upper left',frameon=False);save(fig,'SC1_atlas_orientation')
def dots(table,states,name,title):
 d=pd.read_csv(T/table);fig,axs=plt.subplots(1,2,figsize=(10,max(5,len(states)*.3)),sharey=True,layout='constrained')
 for ax,dis,heading in zip(axs,['myeloid leukemia','normal'],['AML sample origin','Healthy donor origin']):
  for y,st in enumerate(states):
   z=d[(d.state==st)&(d.disease==dis)].set_index('gene').reindex(G)
   sc=ax.scatter(range(5),[y]*5,s=8+220*z.median_detection.fillna(0),c=z.median_log2cpm1,cmap='viridis',vmin=0,vmax=12,edgecolors='#555555',linewidths=.3)
   if len(z) and pd.notna(z.n_donors.iloc[0]):ax.text(4.65,y,f'n={int(z.n_donors.iloc[0])}',va='center',fontsize=8)
  ax.set(xticks=range(5),xticklabels=['ACADSB (−)','ACAT2 (+)','ALDH2 (+)','BCAT1 (+)','OXCT1 (+)'],yticks=range(len(states)),yticklabels=states,xlim=(-.5,5.8),ylim=(len(states)-.5,-.5),title=heading)
  ax.tick_params(axis='x',labelrotation=40)
 fig.colorbar(sc,ax=axs,label='Median donor log2(1 + CPM)',shrink=.6)
 for val in [.1,.5,.9]:axs[1].scatter([],[],s=8+220*val,c='gray',label=f'{int(val*100)}%')
 axs[1].legend(title='Median donor detection',loc='lower left',bbox_to_anchor=(0,-.28),ncol=3,frameon=False)
 fig.suptitle(title+'\nDonors equally weighted; ≥50 cells per donor × state',fontsize=11)
 save(fig,name)
dots('broad_expression_summary.csv',order,'SC2_gene_sources','Five-gene expression across author cell types')
primary=pd.read_csv(T/'primary_paired_contrasts.csv');points=pd.read_csv(T/'primary_paired_donor_values.csv')
fig,axs=plt.subplots(1,2,figsize=(11,4),sharey=True,layout='constrained')
for ax,comparison in zip(axs,primary.comparison.unique()):
 q=primary[primary.comparison==comparison].set_index('gene').loc[G]
 for j,g in enumerate(G):
  zz=points[(points.gene==g)&(points.comparison==comparison)].delta
  ax.scatter(zz,rng.normal(j,.07,len(zz)),s=10,alpha=.4,color='#547b99',linewidths=0)
  r=q.loc[g];ax.errorbar(r.median_delta,j,xerr=[[r.median_delta-r.ci_low],[r.ci_high-r.median_delta]],fmt='o',color='#b63a28',capsize=3)
 ax.axvline(0,ls='--',c='gray',lw=.8);ax.set(yticks=range(5),yticklabels=G,xlabel='Within-donor Δ log2(1 + CPM)',title=f'{comparison}\n{int(q.n_donors.iloc[0])} paired AML donors / {int(q.n_studies.iloc[0])} studies');ax.invert_yaxis()
save(fig,'SC3_donor_paired_state_differences')
fine=pd.read_csv(T/'hspc_expression_summary.csv');fst=['HSC','HSC-like','LSC','Prog','Prog-like','GMP','GMP-like','ProMono','ProMono-like','Mono','Mono-like','cDC','cDC-like','pDC','ProB','B','Plasma','earlyEry','lateEry','T','CTL','NK','NA'];fst=[s for s in fst if s in set(fine[fine.n_donors>=5].state)]
dots('hspc_expression_summary.csv',fst,'SC4_HSPC_reference_states','Reference-mapped labels inside the author HSPC compartment')
st=pd.read_csv(T/'study_paired_contrasts.csv');st=st[(st.comparison=='HSPC minus CD14+ Mono')&(st.n_donors>=5)];studies=sorted(st.subset.unique())
fig,axs=plt.subplots(1,5,figsize=(13,max(3,len(studies)*.4)),sharey=True,layout='constrained')
for ax,g in zip(axs,G):
 for y,s in enumerate(studies):
  row=st[(st.gene==g)&(st.subset==s)].iloc[0];ax.errorbar(row.median_delta,y,xerr=[[row.median_delta-row.ci_low],[row.ci_high-row.median_delta]],fmt='o',capsize=2,color='#326a8b')
 ax.axvline(0,ls='--',c='gray',lw=.8);ax.set(title=g,xlabel='Δ log2(1 + CPM)',yticks=range(len(studies)),yticklabels=[s[6:]+' (n='+str(int(st[(st.subset==s)&(st.gene==G[0])].n_donors.iloc[0]))+')' for s in studies]);ax.invert_yaxis()
fig.suptitle('HSPC minus CD14+ Mono: study-specific paired donor effects',fontsize=12);save(fig,'SC5_study_heterogeneity')
p=T/'two_state_score_decomposition.csv'
if p.exists():
 d=pd.read_csv(p);sts=sorted(d.Study.unique());fig,axs=plt.subplots(len(sts),2,figsize=(10,max(3,len(sts)*3.1)),squeeze=False,layout='constrained')
 for i,s in enumerate(sts):
  z=d[d.Study==s]
  for ax,y,title in zip(axs[i],['score_fixed_50_50_RNA','score_composition_reference_constant'],['Fixed 1:1 RNA weights','Composition-only constant reference']):
   sc=ax.scatter(z.score_observed_two_state,z[y],c=z.hspc_RNA_fraction_two_states,cmap='coolwarm',vmin=0,vmax=1,s=35,edgecolors='white',linewidths=.5)
   q=pd.read_csv(T/'two_state_score_correlations.csv');q=q[(q.Study==s)&(q.x=='score_observed_two_state')&(q.y==y)].iloc[0]
   ax.set(xlabel='Observed two-state expression score',ylabel=title,title=f'{s}: n={len(z)}, ρ={q.spearman_rho:.2f} [{q.ci_low:.2f}, {q.ci_high:.2f}]')
 fig.colorbar(sc,ax=axs,label='HSPC fraction of captured two-state RNA',shrink=.6);save(fig,'SC6_composition_and_within_state')
# Marker check is descriptive validation of supplied fine annotations, never used to redefine score-high cells.
markers=['CD34','KIT','GATA2','MPO','ELANE','LYZ','LST1','CD79A','MS4A1','MZB1','JCHAIN','HBB','GYPA','CD3D','NKG7']
v=pd.read_csv(R/'intermediate/gene_metadata.csv.gz');markers=[g for g in markers if g in set(v.gene_symbol)]
ix=[int(np.flatnonzero(v.gene_symbol==g)[0]) for g in markers]
m=sp.load_npz(R/'intermediate/fine_sample_counts.npz')[:,ix].toarray();meta=pd.read_csv(R/'intermediate/fine_sample_groups.csv',keep_default_na=False)
for j,g in enumerate(markers):meta[g]=m[:,j]
meta=meta[~meta.Study.isin(['setty_2019','stetson_2021'])]
dd=meta.groupby(['donor_id','state','disease'],observed=True)[['n_cells','library_counts']+markers].sum().reset_index();dd=dd[dd.n_cells>=50]
for g in markers:dd[g]=np.log2(1+1e6*dd[g]/dd.library_counts)
dd.to_csv(T/'hspc_marker_donor_expression.csv',index=False)
hm=dd[dd.disease!='normal'].groupby('state')[markers].median().reindex(fst);hm.to_csv(T/'hspc_marker_median_expression.csv')
fig,ax=plt.subplots(figsize=(11,max(5,len(fst)*.3)),layout='constrained');sns.heatmap(hm,cmap='viridis',ax=ax,cbar_kws={'label':'Median donor log2(1 + CPM)'});ax.set(title='Marker audit of reference labels within author HSPCs (AML origin)',xlabel='',ylabel='Supplied reference label');save(fig,'SC7_HSPC_marker_audit')
print('Figures complete')
