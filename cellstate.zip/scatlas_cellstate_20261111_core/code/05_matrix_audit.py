from pathlib import Path
import json
import numpy as np,pandas as pd,h5py
from anndata.io import read_elem
R=Path(__file__).resolve().parents[1];rng=np.random.default_rng(20261111)
records=[]
with h5py.File('/data/scAtlas/AML_scAtlas_CELLxGENE.h5ad','r') as f:
 o=read_elem(f['obs']);raw=f['raw/X'];x=f['X'];rp=raw['indptr'][:];xp=x['indptr'][:]
 for st in o.Study.unique():
  ids=np.flatnonzero(o.Study==st)
  for i in rng.choice(ids,min(10,len(ids)),replace=False):
   ra,rb=rp[i:i+2];xa,xb=xp[i:i+2];rv=raw['data'][ra:rb].astype(float);xv=x['data'][xa:xb].astype(float)
   identical_structure=np.array_equal(raw['indices'][ra:rb],x['indices'][xa:xb]);relspread=np.nan;target=np.nan
   if identical_structure:
    ok=(rv>0)&(xv>0);ratio=np.expm1(xv[ok])/rv[ok]
    med=np.median(ratio);relspread=float(np.max(np.abs(ratio-med))/med);target=float(rv.sum()*med)
   records.append(dict(Study=st,cell_id=o.index[i],n_nonzero=int((rv>0).sum()),library_counts=rv.sum(),identical_raw_X_sparsity=identical_structure,exp_X_over_raw_relative_max_deviation=relspread,inferred_normalization_total_on_exported_genes=target))
 pd.DataFrame(records).to_csv(R/'tables/X_raw_relationship_audit.csv',index=False)
 pd.Series(o.is_primary_data.value_counts()).to_csv(R/'tables/is_primary_data_counts.csv')
 print(pd.DataFrame(records).groupby('Study').agg(n=('cell_id','size'),median_library=('library_counts','median'),max_transform_deviation=('exp_X_over_raw_relative_max_deviation','max'),median_normalization_total=('inferred_normalization_total_on_exported_genes','median')).to_string())
