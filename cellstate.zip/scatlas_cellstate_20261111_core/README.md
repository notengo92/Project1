# scAtlas 核心结果包

优先打开 results_browser.html 查看图表，或 report/results_report.md 查看完整研究结论。
论文段落：report/manuscript_results_CN.md / manuscript_results_EN.md。
数据能力与设计：report/data_capability_and_design.md。

本包包含报告、论文段落、全部PDF/PNG图、供者级结果及相关统计表、分析代码、模型参数、通路定义和精简来源记录。保留供者级数值，便于核对图形、效应和纳入范围。

已排除日志、大型中间矩阵、逐细胞数据、作者原始注释压缩包和下载的论文/代码等原始资料。原始执行目录及完整压缩包均保留。

results_review.ipynb 可在现有 py3_11 内核中从本包根目录运行，用于读取已保存结果，不需要重新处理大矩阵。Notebook未通过Jupyter执行器运行；其引用的结果文件均已包含。

code/ 保存原分析代码供方法复核。完整重算仍需要原h5ad及完整执行目录中的中间文件/来源资料；不要把本精简包当成完整的计算环境直接执行 run_local.sh。

provenance/ 中的输入哈希和 validation.json 记录原完整分析的校验结果；core_file_manifest.csv 仅列出本核心包文件及其SHA256，不包含清单自身。压缩包另行进行了CRC完整性及文件内容一致性校验。
